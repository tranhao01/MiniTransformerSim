"""Mini Transformer Simulation

This script provides a minimal, self‑contained example of the core building
blocks used in transformer models. It generates random query, key and value
vectors for a tiny vocabulary and computes encoder self‑attention,
decoder masked self‑attention and cross‑attention. The resulting weight
matrices are visualised as heatmaps using matplotlib, and a dummy
predicting head illustrates how logits for the next token can be produced.

The goal of this example is purely didactic – none of the values are
learned and therefore the outputs are not meaningful for real NLP tasks.

Usage:
    python mini_transformer_simulation.py

Requirements:
    numpy
    matplotlib
"""

import numpy as np
import matplotlib.pyplot as plt


def softmax(x, mask=None):
    """Compute a row‑wise softmax with optional mask.

    Args:
        x (np.ndarray): The input matrix.
        mask (np.ndarray | None): A boolean matrix where True entries are
            positions that should be masked (set to -inf before softmax).

    Returns:
        np.ndarray: The softmax output.
    """
    if mask is not None:
        x = x.copy()
        x[mask] = -np.inf
    x = x - np.max(x, axis=-1, keepdims=True)
    exp = np.exp(x)
    sum_exp = np.sum(exp, axis=-1, keepdims=True)
    return exp / sum_exp


def compute_attention(Q: np.ndarray, K: np.ndarray, V: np.ndarray, mask=None):
    """Compute scaled dot‑product attention.

    Args:
        Q (np.ndarray): Query vectors of shape (n_tokens, d_model).
        K (np.ndarray): Key vectors of shape (n_tokens, d_model).
        V (np.ndarray): Value vectors of shape (n_tokens, d_model).
        mask (np.ndarray | None): Optional boolean mask of shape (n_tokens, n_tokens)
            indicating where attention should not be paid (True means mask).

    Returns:
        np.ndarray: Attention weights of shape (n_tokens, n_tokens).
        np.ndarray: The weighted sum (context vectors) of shape (n_tokens, d_model).
    """
    d_k = Q.shape[-1]
    scores = Q @ K.T / np.sqrt(d_k)
    weights = softmax(scores, mask)
    context = weights @ V
    return weights, context


def plot_heatmap(data: np.ndarray, labels: list[str], title: str, filename: str):
    """Plot a heatmap and save it as an image.

    Args:
        data (np.ndarray): 2D array of values to plot.
        labels (list[str]): The labels for both axes (assumes square matrix).
        title (str): The title of the plot.
        filename (str): The output filename (PNG).
    """
    plt.figure(figsize=(4, 3))
    plt.imshow(data, cmap="viridis", aspect="auto")
    plt.colorbar()
    plt.xticks(range(len(labels)), labels, rotation=45, ha="right")
    plt.yticks(range(len(labels)), labels)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()


def main():
    tokens_enc = ["The", "cat", "sat", "because", "it", "was", "tired"]
    tokens_dec = ["<s>", "The", "cat"]

    d_model = 16

    np.random.seed(42)
    Q_enc = np.random.randn(len(tokens_enc), d_model)
    K_enc = np.random.randn(len(tokens_enc), d_model)
    V_enc = np.random.randn(len(tokens_enc), d_model)

    attn_enc, context_enc = compute_attention(Q_enc, K_enc, V_enc)
    plot_heatmap(attn_enc, tokens_enc, "Encoder Self‑Attention (Head 0)",
                 "encoder_self_attention.png")

    Q_dec = np.random.randn(len(tokens_dec), d_model)
    K_dec = np.random.randn(len(tokens_dec), d_model)
    V_dec = np.random.randn(len(tokens_dec), d_model)

    mask = np.triu(np.ones((len(tokens_dec), len(tokens_dec)), dtype=bool), k=1)
    attn_dec, context_dec = compute_attention(Q_dec, K_dec, V_dec, mask=mask)
    plot_heatmap(attn_dec, tokens_dec, "Decoder Masked Self‑Attention (Head 0)",
                 "decoder_masked_self_attention.png")

    Q_cross = context_dec
    attn_cross, context_cross = compute_attention(Q_cross, K_enc, V_enc)
    plot_heatmap(attn_cross, tokens_enc,
                 "Cross‑Attention (Head 0)", "cross_attention.png")

    vocab = ["cat", "dog", "sleep", "mat", "because", "it", "sat", "tired", "was", "the"]
    W_proj = np.random.randn(d_model, len(vocab))
    logits = context_cross[-1] @ W_proj
    probs = softmax(logits.reshape(1, -1)).ravel()
    top5_idx = probs.argsort()[-5:][::-1]
    print("Top‑5 predicted tokens (dummy head):")
    for idx in top5_idx:
        print(f"  {vocab[idx]}: {probs[idx]:.3f}")

    print("\nPlots saved as encoder_self_attention.png, decoder_masked_self_attention.png, "
          "and cross_attention.png.")


if __name__ == "__main__":
    main()
